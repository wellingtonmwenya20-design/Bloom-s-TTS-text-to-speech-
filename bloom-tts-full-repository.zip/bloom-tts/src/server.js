import "dotenv/config";
import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import path from "node:path";
import { fileURLToPath } from "node:url";

const filename = fileURLToPath(import.meta.url);
const dirname = path.dirname(filename);
const app = express();
const port = process.env.PORT || 3000;

app.disable("x-powered-by");
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "data:"],
      connectSrc: ["'self'"],
      mediaSrc: ["'self'", "blob:"]
    }
  }
}));
app.use(express.json({ limit: "32kb" }));
app.use("/api", rateLimit({
  windowMs: 60 * 1000,
  limit: 60,
  standardHeaders: "draft-7",
  legacyHeaders: false
}));

app.get("/health", (_req, res) => {
  res.json({ status: "ok", service: "Bloom TTS" });
});

app.get("/api/info", (_req, res) => {
  res.json({
    name: "Bloom TTS",
    version: "1.0.0",
    engine: "Web Speech API",
    synthesis: "Browser SpeechSynthesis",
    note: "Available voices depend on the browser, operating system and installed voice packs."
  });
});

app.use(express.static(path.join(dirname, "../public")));

app.get("*", (_req, res) => {
  res.sendFile(path.join(dirname, "../public/index.html"));
});

app.listen(port, "0.0.0.0", () => {
  console.log(`Bloom TTS running on port ${port}`);
});
