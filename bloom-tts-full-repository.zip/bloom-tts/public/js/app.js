(() => {
  const synth = window.speechSynthesis;
  const textInput = document.querySelector("#text-input");
  const languageSelect = document.querySelector("#language-select");
  const voiceSelect = document.querySelector("#voice-select");
  const speakButton = document.querySelector("#speak");
  const pauseButton = document.querySelector("#pause");
  const resumeButton = document.querySelector("#resume");
  const stopButton = document.querySelector("#stop");
  const statusText = document.querySelector("#status-text");
  const statusDot = document.querySelector("#status-dot");
  const languageNotice = document.querySelector("#language-notice");
  const rateInput = document.querySelector("#rate");
  const pitchInput = document.querySelector("#pitch");
  const charCount = document.querySelector("#char-count");

  let voices = [];
  let currentUtterance = null;

  function setStatus(message, active = false) {
    statusText.textContent = message;
    statusDot.classList.toggle("active", active);
  }

  function updateButtons() {
    const supported = Boolean(synth);
    speakButton.disabled = !supported || !textInput.value.trim();
    pauseButton.disabled = !supported || !synth.speaking || synth.paused;
    resumeButton.disabled = !supported || !synth.paused;
    stopButton.disabled = !supported || (!synth.speaking && !synth.pending);
  }

  function updateCount() {
    charCount.textContent = `${textInput.value.length} / 5000`;
    speakButton.disabled = !synth || !textInput.value.trim();
  }

  function loadLanguages() {
    for (const language of window.BLOOM_LANGUAGES) {
      const option = document.createElement("option");
      option.value = language.code;
      option.textContent = language.name;
      languageSelect.append(option);
    }

    document.querySelector("#language-tags").replaceChildren(
      ...window.BLOOM_LANGUAGES.map((language) => {
        const tag = document.createElement("span");
        tag.className = "tag";
        tag.textContent = language.name;
        return tag;
      })
    );
  }

  function loadVoices() {
    if (!synth) {
      voiceSelect.innerHTML = '<option value="">Speech synthesis is not supported</option>';
      setStatus("This browser does not support speech synthesis.");
      updateButtons();
      return;
    }

    voices = synth.getVoices();
    const previous = voiceSelect.value;
    voiceSelect.replaceChildren();

    const automatic = document.createElement("option");
    automatic.value = "";
    automatic.textContent = "Automatic device voice";
    voiceSelect.append(automatic);

    voices.forEach((voice, index) => {
      const option = document.createElement("option");
      option.value = String(index);
      option.textContent = `${voice.name} (${voice.lang})${voice.default ? " — Default" : ""}`;
      voiceSelect.append(option);
    });

    if (previous && voices[Number(previous)]) voiceSelect.value = previous;
    updateVoiceNotice();
  }

  function updateVoiceNotice() {
    const selectedLanguage = languageSelect.value;
    const matching = voices.filter((voice) =>
      voice.lang.toLowerCase().startsWith(selectedLanguage.split("-")[0].toLowerCase())
    );
    const languageName = languageSelect.selectedOptions[0]?.textContent || "selected language";
    if (matching.length) {
      languageNotice.textContent = `${matching.length} voice(s) appear to match ${languageName}. Voice quality and pronunciation depend on your device.`;
    } else {
      languageNotice.textContent = `No installed voice was detected for ${languageName}. Your browser may use a fallback voice, which may pronounce this language incorrectly.`;
    }
  }

  function chooseLanguageFromText() {
    const detected = window.detectBloomLanguage(textInput.value);
    if (detected) {
      languageSelect.value = detected.code;
      updateVoiceNotice();
      setStatus(`Language suggestion: ${detected.name}. Check the selection before speaking.`);
    }
  }

  function stopSpeech() {
    if (synth) synth.cancel();
    currentUtterance = null;
    setStatus("Speech stopped");
    updateButtons();
  }

  function speak() {
    if (!synth) {
      setStatus("Speech synthesis is not supported in this browser.");
      return;
    }
    const text = textInput.value.trim();
    if (!text) {
      setStatus("Enter some text first.");
      textInput.focus();
      return;
    }

    synth.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = languageSelect.value;
    utterance.rate = Number(rateInput.value);
    utterance.pitch = Number(pitchInput.value);

    const voiceIndex = voiceSelect.value;
    if (voiceIndex !== "" && voices[Number(voiceIndex)]) {
      utterance.voice = voices[Number(voiceIndex)];
      utterance.lang = voices[Number(voiceIndex)].lang;
    } else {
      const languagePrefix = languageSelect.value.split("-")[0].toLowerCase();
      const matchingVoice = voices.find((voice) =>
        voice.lang.toLowerCase().startsWith(languagePrefix)
      );
      if (matchingVoice) utterance.voice = matchingVoice;
    }

    utterance.onstart = () => {
      currentUtterance = utterance;
      setStatus("Bloom is speaking...", true);
      updateButtons();
    };
    utterance.onend = () => {
      currentUtterance = null;
      setStatus("Speech completed");
      updateButtons();
    };
    utterance.onerror = (event) => {
      currentUtterance = null;
      setStatus(`Speech error: ${event.error || "unable to speak"}`);
      updateButtons();
    };

    currentUtterance = utterance;
    synth.speak(utterance);
    setStatus("Preparing speech...", true);
    updateButtons();
  }

  loadLanguages();
  if ("speechSynthesis" in window) {
    loadVoices();
    synth.addEventListener?.("voiceschanged", loadVoices);
    // Some browsers populate the voice list shortly after page load.
    window.setTimeout(loadVoices, 500);
  } else {
    setStatus("This browser does not support the Web Speech API.");
    loadVoices();
  }

  speakButton.addEventListener("click", speak);
  pauseButton.addEventListener("click", () => {
    if (synth?.speaking && !synth.paused) {
      synth.pause();
      setStatus("Speech paused");
      updateButtons();
    }
  });
  resumeButton.addEventListener("click", () => {
    if (synth?.paused) {
      synth.resume();
      setStatus("Speech resumed", true);
      updateButtons();
    }
  });
  stopButton.addEventListener("click", stopSpeech);
  textInput.addEventListener("input", updateCount);
  languageSelect.addEventListener("change", updateVoiceNotice);
  voiceSelect.addEventListener("change", updateVoiceNotice);
  rateInput.addEventListener("input", () => {
    document.querySelector("#rate-value").textContent = `${Number(rateInput.value).toFixed(1)}×`;
  });
  pitchInput.addEventListener("input", () => {
    document.querySelector("#pitch-value").textContent = Number(pitchInput.value).toFixed(1);
  });
  document.querySelector("#clear-text").addEventListener("click", () => {
    stopSpeech();
    textInput.value = "";
    updateCount();
    setStatus("Text cleared");
    textInput.focus();
  });

  // Light language suggestion after the user pauses typing.
  let detectTimer;
  textInput.addEventListener("input", () => {
    window.clearTimeout(detectTimer);
    detectTimer = window.setTimeout(chooseLanguageFromText, 900);
  });

  window.addEventListener("beforeunload", () => synth?.cancel());
  updateCount();
  updateButtons();
})();
