/*
 * Language metadata and lightweight keyword detection.
 * Detection selects a language preference; it does not translate text
 * or guarantee that the device has a matching speech voice.
 */
window.BLOOM_LANGUAGES = [
  { code: "en-US", name: "English", aliases: ["english"], hints: ["the", "and", "what", "hello", "please"] },
  { code: "fr-FR", name: "French", aliases: ["français", "french"], hints: ["bonjour", "merci", "je", "vous", "avec"] },
  { code: "bem-ZM", name: "Bemba", aliases: ["ichibemba", "bemba"], hints: ["muli", "shani", "natotela", "mukwai", "bwino"] },
  { code: "ny-ZM", name: "Nyanja / Chichewa", aliases: ["nyanja", "chichewa"], hints: ["bwanji", "zikomo", "ndikufuna", "inu", "moni"] },
  { code: "toi-ZM", name: "Tonga", aliases: ["chitonga", "tonga"], hints: ["mwaanjani", "twalumba", "bwino"] },
  { code: "loz-ZM", name: "Lozi", aliases: ["silozi", "lozi"], hints: ["lumela", "ni", "litumezi"] },
  { code: "tum-ZM", name: "Tumbuka", aliases: ["tumbuka"], hints: ["monile", "yewo", "uli"] },
  { code: "lam-ZM", name: "Lamba", aliases: ["lamba"], hints: ["muli", "twatotela"] },
  { code: "sw-KE", name: "Swahili", aliases: ["kiswahili", "swahili"], hints: ["habari", "asante", "tafadhali", "karibu"] },
  { code: "zu-ZA", name: "Zulu", aliases: ["isizulu", "zulu"], hints: ["sawubona", "ngiyabonga", "unjani"] }
];

window.detectBloomLanguage = function (text) {
  const normalized = ` ${String(text || "").toLowerCase().replace(/[^\p{L}\s]/gu, " ")} `;
  let best = null;
  let bestScore = 0;

  for (const language of window.BLOOM_LANGUAGES) {
    let score = 0;
    for (const hint of language.hints) {
      const escaped = hint.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      if (new RegExp(`(?:^|\\s)${escaped}(?:$|\\s)`, "u").test(normalized)) score += 1;
    }
    for (const alias of language.aliases) {
      if (normalized.includes(alias)) score += 3;
    }
    if (score > bestScore) {
      best = language;
      bestScore = score;
    }
  }
  return bestScore > 0 ? best : window.BLOOM_LANGUAGES[0];
};
